A Pen created at CodePen.io. You can find this one at https://codepen.io/agusandreol/pen/MxYozB.

 Image slider with only a next button, when the last slide is reached it goes back to the first slide.